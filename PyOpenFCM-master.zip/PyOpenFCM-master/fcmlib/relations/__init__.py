from .simplesigmoid import RSimpleSigmoid
from .threeterm import R3Term
from .neural import RNeural

del simplesigmoid
del threeterm
del neural