from .piecewiselinear import PiecewiseLinear
from .polynome import Polynome
from .predefined import Predefined
from .sigmoid import Sigmoid

del piecewiselinear
del polynome
del predefined
del sigmoid