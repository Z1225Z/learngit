var dir_38f8a2ea77cb3b8e1b7b6b8365fd21a8 =
[
    [ "__init__.py", "relations_2____init_____8py.html", null ],
    [ "neural.py", "neural_8py.html", [
      [ "RNeural", "classfcmlib_1_1relations_1_1neural_1_1_r_neural.html", "classfcmlib_1_1relations_1_1neural_1_1_r_neural" ]
    ] ],
    [ "simplesigmoid.py", "simplesigmoid_8py.html", [
      [ "RSimpleSigmoid", "classfcmlib_1_1relations_1_1simplesigmoid_1_1_r_simple_sigmoid.html", "classfcmlib_1_1relations_1_1simplesigmoid_1_1_r_simple_sigmoid" ]
    ] ],
    [ "threeterm.py", "threeterm_8py.html", [
      [ "R3Term", "classfcmlib_1_1relations_1_1threeterm_1_1_r3_term.html", "classfcmlib_1_1relations_1_1threeterm_1_1_r3_term" ]
    ] ]
];