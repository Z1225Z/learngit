var searchData=
[
  ['slope',['slope',['../classfcmlib_1_1functions_1_1sigmoid_1_1_sigmoid.html#a460024d0f52623081821d663288ea007',1,'fcmlib::functions::sigmoid::Sigmoid']]],
  ['start',['start',['../classfcmlib_1_1functions_1_1piecewiselinear_1_1_piece.html#a342cabbaa444b8f602172664d119d58a',1,'fcmlib::functions::piecewiselinear::Piece']]]
];
