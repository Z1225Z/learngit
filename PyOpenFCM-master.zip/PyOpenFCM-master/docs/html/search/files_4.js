var searchData=
[
  ['neural_2epy',['neural.py',['../neural_8py.html',1,'']]]
];
