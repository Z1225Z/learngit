var searchData=
[
  ['sigmoid_2epy',['sigmoid.py',['../sigmoid_8py.html',1,'']]],
  ['simplesigmoid_2epy',['simplesigmoid.py',['../simplesigmoid_8py.html',1,'']]]
];
