var indexSectionsWithContent =
{
  0: "_abcdefgilmnoprstuvwxy",
  1: "cfiprs",
  2: "f",
  3: "_cfinpst",
  4: "_abcdegilprsu",
  5: "abcdefimnoprsvwxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables"
};

