var searchData=
[
  ['threeterm_2epy',['threeterm.py',['../threeterm_8py.html',1,'']]]
];
