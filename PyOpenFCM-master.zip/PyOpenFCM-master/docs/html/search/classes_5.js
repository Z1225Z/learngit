var searchData=
[
  ['sigmoid',['Sigmoid',['../classfcmlib_1_1functions_1_1sigmoid_1_1_sigmoid.html',1,'fcmlib::functions::sigmoid']]]
];
