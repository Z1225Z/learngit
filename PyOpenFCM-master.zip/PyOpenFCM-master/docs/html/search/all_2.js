var searchData=
[
  ['b',['b',['../classfcmlib_1_1functions_1_1piecewiselinear_1_1_piece.html#a644a4f08c0389a48abcd64e5df921c13',1,'fcmlib::functions::piecewiselinear::Piece']]],
  ['backprop',['backprop',['../classfcmlib_1_1interfaces_1_1_i_relation.html#a9d36de0b5f54a5f5088ce77e7b7f3eeb',1,'fcmlib.interfaces.IRelation.backprop()'],['../classfcmlib_1_1relations_1_1neural_1_1_r_neural.html#aeebe52063bc2105f11b2a1517ba0821d',1,'fcmlib.relations.neural.RNeural.backprop()'],['../classfcmlib_1_1relations_1_1simplesigmoid_1_1_r_simple_sigmoid.html#a76546f9ff625bf1254446afe1e5c40f9',1,'fcmlib.relations.simplesigmoid.RSimpleSigmoid.backprop()'],['../classfcmlib_1_1relations_1_1threeterm_1_1_r3_term.html#a1f367f4a5d5dea5ac9a7b8c003646ce0',1,'fcmlib.relations.threeterm.R3Term.backprop()']]]
];
