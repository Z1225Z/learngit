var searchData=
[
  ['maximum',['maximum',['../classfcmlib_1_1functions_1_1sigmoid_1_1_sigmoid.html#a0c46b108dbf0f528e0f04dcc5399da7d',1,'fcmlib::functions::sigmoid::Sigmoid']]]
];
